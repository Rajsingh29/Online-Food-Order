<div class="footer">
       <div class="wrapper">
        <p class="text-center">2022 All rights reserved, Some Restaurant. Developed By- <a href="https://www.linkedin.com/in/anup-singh-521a19238/?lipi=urn%3Ali%3Apage%3Ad_flagship3_feed%3BAjYJ7CmKQ4WEPT63Mffyiw%3D%3D">Anup Singh</a></p>
        </div>
    </div>
    </body>
</html>