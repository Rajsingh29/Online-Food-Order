<!-- social Section Starts Here -->
<section class="social">
        <div class="container text-center">
            <ul>
                <li>
                    <a href="https://www.facebook.com/profile.php?id=100009351566766" target="_blank"><img src="https://img.icons8.com/fluent/50/000000/facebook-new.png"/></a>
                </li>
                <li>
                    <a href="https://www.instagram.com/anupsinghania1/" target="_blank"><img src="https://img.icons8.com/fluent/48/000000/instagram-new.png"/></a>
                </li>
                <li>
                    <a href="https://twitter.com/Anupsinghania10" target="_blank"><img src="https://img.icons8.com/fluent/48/000000/twitter.png"/></a>
                </li>
            </ul>
        </div>
    </section>
    <!-- social Section Ends Here -->

    <!-- footer Section Starts Here -->
    <section class="footer">
        <div class="container text-center">
            <p>All rights reserved. Designed By <a href="https://www.linkedin.com/in/anup-singh-521a19238/?lipi=urn%3Ali%3Apage%3Ad_flagship3_feed%3BAjYJ7CmKQ4WEPT63Mffyiw%3D%3D" target="_blank">Anup Singh</a></p>
        </div>
    </section>
    <!-- footer Section Ends Here -->

</body>
</html>