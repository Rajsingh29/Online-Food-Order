#include <stdlib.h>
struct node {
    int data;
    struct node* left;
    struct node* right;
};
struct node* newNode(int data)
{#include <stdio.h>

    struct node* node
        = (struct node*)malloc(sizeof(struct node));
    node->data = data;
    node->left = NULL;
    node->right = NULL;
 
    return (node);
}
void printInorder(struct node* node)
{
    if (node == NULL)
        return;
    printInorder(node->left);
    printf("%d ", node->data);
    printInorder(node->right);
}
void printPreorder(struct node* node)
{
    if (node == NULL)
        return;
    printf("%d ", node->data);
    printPreorder(node->left);
    printPreorder(node->right);
}
void printPostorder(struct node* node)
{
    if (node == NULL)
        return;
    printPostorder(node->left);
    printPostorder(node->right);
    printf("%d ", node->data);
}
int main()
{
    struct node* root = newNode(25);
    root->left = newNode(15);
    root->right = newNode(50);
    root->left->left = newNode(10);
    root->left->right = newNode(22);
    root->left->left->left = newNode(4);
    root->left->left->right = newNode(12);
    root->left->right->left = newNode(18);
    root->left->right->right = newNode(24);
    root->right->left = newNode(35);
    root->right->right = newNode(70);
    root->right->left->left = newNode(31);
    root->right->left->right = newNode(44);
    root->right->right->left = newNode(66);
    root->right->right->right = newNode(90);
    printf("\nInorder traversal of binary tree is \n");
    printInorder(root);
    
    printf("\nPreorder traversal of binary tree is \n");
    printPreorder(root);
    
    printf("\nPostorder traversal of binary tree is \n");
    printPostorder(root);
    return 0;
}
